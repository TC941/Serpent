# Serpent, jeu Snake pour Android

Le jeu est une page web (`app/src/main/assets/index.html`) affichée dans une application Android native minimale.

## Obtenir l'APK (sans rien installer sur ton ordinateur)

1. Crée un compte sur https://github.com si tu n'en as pas.
2. Crée un nouveau dépôt (bouton **New**), nom au choix, public ou privé.
3. Envoie-y tout le contenu de ce dossier, y compris le dossier caché `.github`.
   Sur le site : **Add file → Upload files**, puis glisse les fichiers et dossiers.
   Si tu es sur un téléphone, passe par la version bureau du site (menu du navigateur → « Site pour ordinateur »).
4. Ouvre l'onglet **Actions**. La compilation démarre toute seule (environ 3 à 5 minutes).
   Si rien ne démarre : choisis **Build APK** dans la liste, puis **Run workflow**.
5. Quand la ligne est verte, ouvre-la et télécharge **serpent-apk** en bas de page (fichier zip contenant `app-debug.apk`).

## Installer l'APK sur le téléphone

1. Dézippe le fichier téléchargé et ouvre `app-debug.apk`.
2. Android demande d'autoriser l'installation depuis cette source : accepte, puis installe.
3. L'application **Serpent** apparaît dans tes applications.

## Jouer

Glisse le doigt n'importe où sur l'écran pour tourner. Le record est gardé sur le téléphone.

## Modifier le jeu

Tout le jeu est dans `app/src/main/assets/index.html`. Après une modification, renvoie le fichier sur GitHub : une nouvelle compilation produit un nouvel APK.
